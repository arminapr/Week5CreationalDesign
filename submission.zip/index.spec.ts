
import { StandardCalculatorModel } from './index';

describe('week5-creational-DP', (): void => {

  describe('StandardCalculatorModel', (): void => {

    it('StandardCalculatorModel exists', (): void => {

      expect(StandardCalculatorModel).toBeDefined();

    });

  });

});
